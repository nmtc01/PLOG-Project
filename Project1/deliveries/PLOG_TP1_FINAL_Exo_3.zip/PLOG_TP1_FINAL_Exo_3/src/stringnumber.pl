%used to convert a string into a number and vice versa
string_number(0, '0').
string_number(1, '1').
string_number(2, '2').
string_number(3, '3').
string_number(4, '4').
string_number(5, '5').
string_number(6, '6').
string_number(7, '7').
string_number(8, '8').
string_number(9, '9').
string_number(10, '10').
string_number(10, '11').