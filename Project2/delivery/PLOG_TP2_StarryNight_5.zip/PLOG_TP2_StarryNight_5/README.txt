Para correr o jogo, após consulta do ficheiro starry.pl, deve-se escrever
"starry(Night)."
No menu há duas opções: a primeira gera tabuleiros aleatórios, precisando o utilizador de apenas introduzir o tamanho do board.
A segunda gera tabuleiros cujas restrições exteriores o utilizador deve introduzir. 